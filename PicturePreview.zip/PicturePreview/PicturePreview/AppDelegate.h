//
//  AppDelegate.h
//  PicturePreview
//
//  Created by BaoBaoDaRen on 2019/7/24.
//  Copyright © 2019 Boris. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

